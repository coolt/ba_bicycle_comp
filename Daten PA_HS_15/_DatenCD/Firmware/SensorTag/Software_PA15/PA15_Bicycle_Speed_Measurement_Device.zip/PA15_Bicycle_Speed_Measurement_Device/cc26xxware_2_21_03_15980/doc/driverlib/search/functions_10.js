var searchData=
[
  ['vimsconfigure',['VIMSConfigure',['../group__vims__api.html#ga33025ed4f7c5b3694f1bbc198e36e3e8',1,'VIMSConfigure(uint32_t ui32Base, bool bRoundRobin, bool bPrefetch):&#160;vims.c'],['../group__vims__api.html#ga33025ed4f7c5b3694f1bbc198e36e3e8',1,'VIMSConfigure(uint32_t ui32Base, bool bRoundRobin, bool bPrefetch):&#160;vims.c']]],
  ['vimslinebufdisable',['VIMSLineBufDisable',['../group__vims__api.html#gab4b55e753335553abd2d3aa13f2f10bb',1,'vims.h']]],
  ['vimslinebufenable',['VIMSLineBufEnable',['../group__vims__api.html#gaf1db2091144659ec5c1fd972a09f9275',1,'vims.h']]],
  ['vimsmodeget',['VIMSModeGet',['../group__vims__api.html#gaf2a0eaa5209f808c8e83f9dd3b0200f8',1,'VIMSModeGet(uint32_t ui32Base):&#160;vims.c'],['../group__vims__api.html#gaf2a0eaa5209f808c8e83f9dd3b0200f8',1,'VIMSModeGet(uint32_t ui32Base):&#160;vims.c']]],
  ['vimsmodeset',['VIMSModeSet',['../group__vims__api.html#ga1383305e90b9bd37527da503a9997c82',1,'VIMSModeSet(uint32_t ui32Base, uint32_t ui32Mode):&#160;vims.c'],['../group__vims__api.html#ga1383305e90b9bd37527da503a9997c82',1,'VIMSModeSet(uint32_t ui32Base, uint32_t ui32Mode):&#160;vims.c']]],
  ['vimsmodesetblocking',['VIMSModeSetBlocking',['../group__vims__api.html#ga34f71c41326148b0f576c257a812f081',1,'VIMSModeSetBlocking(uint32_t ui32Mode):&#160;vims.c'],['../group__vims__api.html#ga34f71c41326148b0f576c257a812f081',1,'VIMSModeSetBlocking(uint32_t ui32Mode):&#160;vims.c']]]
];
