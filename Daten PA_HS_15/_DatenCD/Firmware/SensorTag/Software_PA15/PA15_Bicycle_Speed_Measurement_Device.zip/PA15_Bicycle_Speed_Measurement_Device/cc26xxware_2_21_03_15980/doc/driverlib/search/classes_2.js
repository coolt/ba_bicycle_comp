var searchData=
[
  ['oschfglobals_5ft',['OscHfGlobals_t',['../struct_osc_hf_globals__t.html',1,'']]]
];
