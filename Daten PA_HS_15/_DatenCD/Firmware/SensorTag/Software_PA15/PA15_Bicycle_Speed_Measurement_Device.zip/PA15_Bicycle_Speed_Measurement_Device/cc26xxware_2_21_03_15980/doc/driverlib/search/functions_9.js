var searchData=
[
  ['membuswrkaroundhapierasesector',['MemBusWrkAroundHapiEraseSector',['../flash_8c.html#a2255b3f8999e1235ddf26e49d41265fd',1,'MemBusWrkAroundHapiEraseSector(uint32_t ui32Address):&#160;flash.c'],['../rom_8h.html#a2255b3f8999e1235ddf26e49d41265fd',1,'MemBusWrkAroundHapiEraseSector(uint32_t ui32Address):&#160;flash.c']]],
  ['membuswrkaroundhapiprogramflash',['MemBusWrkAroundHapiProgramFlash',['../flash_8c.html#a8508e1d7084d01df379d827f74fe7b17',1,'MemBusWrkAroundHapiProgramFlash(uint8_t *pui8DataBuffer, uint32_t ui32Address, uint32_t ui32Count):&#160;flash.c'],['../rom_8h.html#a8508e1d7084d01df379d827f74fe7b17',1,'MemBusWrkAroundHapiProgramFlash(uint8_t *pui8DataBuffer, uint32_t ui32Address, uint32_t ui32Count):&#160;flash.c']]]
];
