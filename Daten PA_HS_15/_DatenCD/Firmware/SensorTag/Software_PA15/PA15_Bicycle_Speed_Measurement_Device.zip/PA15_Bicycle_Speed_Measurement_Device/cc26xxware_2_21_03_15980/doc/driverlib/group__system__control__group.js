var group__system__control__group =
[
    [ "CCFG Read", "group__ccfgread__api.html", "group__ccfgread__api" ],
    [ "Chip Info", "group___chip_info.html", "group___chip_info" ],
    [ "[debug] Debug", "group__debug__api.html", "group__debug__api" ],
    [ "Driverlib Release", "group__driverlib__release__api.html", "group__driverlib__release__api" ],
    [ "[flash] Flash", "group__flash__api.html", "group__flash__api" ],
    [ "[flashsafe] Flash Safe", "group__flashsafe__api.html", "group__flashsafe__api" ],
    [ "[osc] Oscillator", "group__osc__api.html", "group__osc__api" ],
    [ "[prcm] Power Reset Clock Manager", "group__prcm__api.html", "group__prcm__api" ],
    [ "[pwr_ctrl] Power Controller", "group__pwrctrl__api.html", "group__pwrctrl__api" ],
    [ "[setup] Setup", "group__setup__api.html", "group__setup__api" ],
    [ "[sys_ctrl] System Controller", "group__sysctrl__api.html", "group__sysctrl__api" ],
    [ "[vims] Versatile Instruction Memory System", "group__vims__api.html", "group__vims__api" ]
];