var searchData=
[
  ['low_5fpower_5fxosc',['LOW_POWER_XOSC',['../group__osc__api.html#ga04a634489a012ad9a677d6c020dbf2d4',1,'osc.h']]]
];
