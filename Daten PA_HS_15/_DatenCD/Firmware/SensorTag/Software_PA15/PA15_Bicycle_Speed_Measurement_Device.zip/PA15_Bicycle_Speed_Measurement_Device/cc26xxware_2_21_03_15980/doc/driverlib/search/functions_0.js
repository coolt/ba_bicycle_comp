var searchData=
[
  ['_5f_5ferror_5f_5f',['__error__',['../group__debug__api.html#ga9cbff4035d547129f9c7c07129d2fa01',1,'__error__(char *pcFilename, uint32_t ui32Line):&#160;debug.c'],['../group__debug__api.html#ga9cbff4035d547129f9c7c07129d2fa01',1,'__error__(char *pcFilename, uint32_t ui32Line):&#160;debug.c']]]
];
