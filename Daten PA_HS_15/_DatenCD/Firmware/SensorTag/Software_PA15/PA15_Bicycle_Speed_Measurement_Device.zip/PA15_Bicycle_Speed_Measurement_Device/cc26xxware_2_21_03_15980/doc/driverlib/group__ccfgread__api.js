var group__ccfgread__api =
[
    [ "CCFGRead_DIS_GPRAM", "group__ccfgread__api.html#gadf70dc1de9bfe6027adaa617fa8c9912", null ],
    [ "CCFGRead_EXT_LF_CLK_DIO", "group__ccfgread__api.html#gad60d6f6c3fe567b859016f610cbe8a55", null ],
    [ "CCFGRead_SCLK_LF_OPTION", "group__ccfgread__api.html#gaafceaa7474b25bfc18e1b1645f55697c", null ],
    [ "SCLK_LF_OPTION_EXTERNAL", "group__ccfgread__api.html#ga94a54961732ded15f07e2cbe16c861ee", null ],
    [ "SCLK_LF_OPTION_RCOSC_LF", "group__ccfgread__api.html#ga6ff022343efc73f3b98aeef28dc3cc2b", null ],
    [ "SCLK_LF_OPTION_XOSC_HF_DLF", "group__ccfgread__api.html#gac01532ae84b3cf134158c66091f92048", null ],
    [ "SCLK_LF_OPTION_XOSC_LF", "group__ccfgread__api.html#gaee4660b3bbcb4df2465a066f9a3bdac0", null ]
];