var group__trng__api =
[
    [ "TRNGConfigure", "group__trng__api.html#ga72ac7c8c57d4f04e9bb0745a20bee469", null ],
    [ "TRNGDisable", "group__trng__api.html#ga687e19fc72e4bc2920936ad32f2408f1", null ],
    [ "TRNGEnable", "group__trng__api.html#ga97a06ec036f6dba52eb6ad69a2dd5023", null ],
    [ "TRNGIntClear", "group__trng__api.html#gaa5121f68054b17e9d47a2f6d82aeae55", null ],
    [ "TRNGIntDisable", "group__trng__api.html#gae659c27ffcb3c13e5fefb74a05bc2a14", null ],
    [ "TRNGIntEnable", "group__trng__api.html#ga14ff11bc5e294cf5c3b04962f37684ef", null ],
    [ "TRNGIntRegister", "group__trng__api.html#gaf3a873aff7dfc478fdb398e56a9c2178", null ],
    [ "TRNGIntStatus", "group__trng__api.html#ga709c1beffe4e95e51fff053666b1e181", null ],
    [ "TRNGIntUnregister", "group__trng__api.html#ga6fb06641f447e074f43de84192e6dfe0", null ],
    [ "TRNGNumberGet", "group__trng__api.html#ga4a73e8ae4dc658cea398d2485d682fa5", null ],
    [ "TRNGReset", "group__trng__api.html#ga96ffc60e1eed25223bad6337c628c837", null ],
    [ "TRNGStatusGet", "group__trng__api.html#gadcd05df76082001af8cbffcbbb7639d7", null ],
    [ "TRNG_FRO_SHUTDOWN", "group__trng__api.html#gaa28d9db33dd25ff579aff8a230df846c", null ],
    [ "TRNG_HI_WORD", "group__trng__api.html#ga6c50114339653a2747148f31490fb83f", null ],
    [ "TRNG_LOW_WORD", "group__trng__api.html#ga845db069a087aebb0132e0a73b61b9a0", null ],
    [ "TRNG_NEED_CLOCK", "group__trng__api.html#ga603a0dbcc736a6cd9a0c104eb59a92f9", null ],
    [ "TRNG_NUMBER_READY", "group__trng__api.html#ga4e37ffb65fbf02c884ce04aeb4291a8f", null ]
];