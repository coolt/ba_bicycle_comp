var searchData=
[
  ['powerqualglobals_5ft',['PowerQualGlobals_t',['../struct_power_qual_globals__t.html',1,'']]]
];
