var group__analog__group =
[
    [ "[adi] Analog to Digital Interface", "group__adi__api.html", "group__adi__api" ],
    [ "[ddi] Digital to Digital Interface", "group__ddi__api.html", "group__ddi__api" ]
];