var searchData=
[
  ['hapitrimdevicecoldreset',['HapiTrimDeviceColdReset',['../setup_8c.html#a908d2409495bfb8265b2e590241519c7',1,'setup.c']]],
  ['hapitrimdevicepowerdown',['HapiTrimDevicePowerDown',['../setup_8c.html#a0a296efd8b968f2d53dc8e8e4ee1ac0d',1,'setup.c']]],
  ['hapitrimdeviceshutdown',['HapiTrimDeviceShutDown',['../setup_8c.html#aafc193315fa2cde6a28ac4925fbfb071',1,'setup.c']]]
];
