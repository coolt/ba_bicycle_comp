var searchData=
[
  ['_5f_5fhapi_5fh_5f_5f',['__HAPI_H__',['../rom_8h.html#af1e640afedecf14758ace5fef1a8ba0b',1,'rom.h']]]
];
