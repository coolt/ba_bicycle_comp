var searchData=
[
  ['peripherals',['Peripherals',['../group__peripheral__group.html',1,'']]]
];
