var searchData=
[
  ['mainpage_2edox',['mainpage.dox',['../mainpage_8dox.html',1,'']]],
  ['maxvalue',['MaxValue',['../struct_h_a_r_d___a_p_i___t.html#a14fee470f846309be1f7f6817f04aacb',1,'HARD_API_T']]],
  ['mcu_5faux_5fret_5fenable',['MCU_AUX_RET_ENABLE',['../group__aonwuc__api.html#ga0ce4c7a5b3fd21d612cf5672427ac767',1,'aon_wuc.h']]],
  ['mcu_5ffixed_5fwake_5fup',['MCU_FIXED_WAKE_UP',['../group__aonwuc__api.html#ga50fce877dfef1e65dffa0525a06b6103',1,'aon_wuc.h']]],
  ['mcu_5fimm_5fwake_5fup',['MCU_IMM_WAKE_UP',['../group__aonwuc__api.html#ga0aa9bb6054e10cf766110c879e0d9bf2',1,'aon_wuc.h']]],
  ['mcu_5fram0_5fretention',['MCU_RAM0_RETENTION',['../group__aonwuc__api.html#ga69a6753520aebd0605806846416bcc19',1,'aon_wuc.h']]],
  ['mcu_5fram1_5fretention',['MCU_RAM1_RETENTION',['../group__aonwuc__api.html#gaa2b3ee9ec8f7ad65bbae3aee4385ec89',1,'aon_wuc.h']]],
  ['mcu_5fram2_5fretention',['MCU_RAM2_RETENTION',['../group__aonwuc__api.html#ga926077b04be4cd1115a5cb444746f4e0',1,'aon_wuc.h']]],
  ['mcu_5fram3_5fretention',['MCU_RAM3_RETENTION',['../group__aonwuc__api.html#ga0a0494b48e64027d15b09ec7beecc551',1,'aon_wuc.h']]],
  ['mcu_5fram_5fblock_5fretention',['MCU_RAM_BLOCK_RETENTION',['../group__aonwuc__api.html#ga9bd790b9498bce15de7ab1819800a94e',1,'aon_wuc.h']]],
  ['mcu_5framrepair_5fdone',['MCU_RAMREPAIR_DONE',['../group__aonwuc__api.html#ga483db2202d87691364773613ae5f8b59',1,'aon_wuc.h']]],
  ['mcu_5fvirt_5fpwoff_5fdisable',['MCU_VIRT_PWOFF_DISABLE',['../group__aonwuc__api.html#ga80b99343024323f5086bccbc5a1cac74',1,'aon_wuc.h']]],
  ['mcu_5fvirt_5fpwoff_5fenable',['MCU_VIRT_PWOFF_ENABLE',['../group__aonwuc__api.html#ga75201f864cf5baf09ce3c2a16e3cefad',1,'aon_wuc.h']]],
  ['meanvalue',['MeanValue',['../struct_h_a_r_d___a_p_i___t.html#a4b757b16045b73a8f2679a4c97741e4d',1,'HARD_API_T']]],
  ['membuswrkaroundhapierasesector',['MemBusWrkAroundHapiEraseSector',['../flash_8c.html#a2255b3f8999e1235ddf26e49d41265fd',1,'MemBusWrkAroundHapiEraseSector(uint32_t ui32Address):&#160;flash.c'],['../rom_8h.html#a2255b3f8999e1235ddf26e49d41265fd',1,'MemBusWrkAroundHapiEraseSector(uint32_t ui32Address):&#160;flash.c']]],
  ['membuswrkaroundhapiprogramflash',['MemBusWrkAroundHapiProgramFlash',['../flash_8c.html#a8508e1d7084d01df379d827f74fe7b17',1,'MemBusWrkAroundHapiProgramFlash(uint8_t *pui8DataBuffer, uint32_t ui32Address, uint32_t ui32Count):&#160;flash.c'],['../rom_8h.html#a8508e1d7084d01df379d827f74fe7b17',1,'MemBusWrkAroundHapiProgramFlash(uint8_t *pui8DataBuffer, uint32_t ui32Address, uint32_t ui32Count):&#160;flash.c']]],
  ['minvalue',['MinValue',['../struct_h_a_r_d___a_p_i___t.html#aa07aa4e28f4956c132b7c5f153dd22ee',1,'HARD_API_T']]]
];
