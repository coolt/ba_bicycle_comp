var group__system__cpu__group =
[
    [ "[cpu] CPU", "group__cpu__api.html", "group__cpu__api" ],
    [ "[interrupt] Interrupt", "group__interrupt__api.html", "group__interrupt__api" ],
    [ "[systick] System Tick", "group__systick__api.html", "group__systick__api" ]
];