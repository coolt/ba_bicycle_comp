var searchData=
[
  ['p_5fhard_5fapi',['P_HARD_API',['../rom_8h.html#a8b19c3180d0900e9b23ea26b27a783fe',1,'rom.h']]],
  ['pd_5fstate_5fcache_5fret',['PD_STATE_CACHE_RET',['../sys__ctrl_8c.html#a3a2508efaf91419390dbc38da69a6f14',1,'sys_ctrl.c']]],
  ['pd_5fstate_5fext_5freg_5fmode',['PD_STATE_EXT_REG_MODE',['../sys__ctrl_8c.html#aebe2ff2123e00eb60449d1fbff952e8f',1,'sys_ctrl.c']]],
  ['pd_5fstate_5frfmem_5fret',['PD_STATE_RFMEM_RET',['../sys__ctrl_8c.html#a9270d6f8c8fb9c65ec1a3a3e0d21cf7b',1,'sys_ctrl.c']]],
  ['pd_5fstate_5fxosc_5flpm',['PD_STATE_XOSC_LPM',['../sys__ctrl_8c.html#aad6bfbe32f675afcb2946016032bf899',1,'sys_ctrl.c']]],
  ['prcm_5fperiph_5findex',['PRCM_PERIPH_INDEX',['../prcm_8c.html#a3a2023f24dc2360b1a108d4b2a5acc99',1,'prcm.c']]],
  ['prcm_5fperiph_5fmaskbit',['PRCM_PERIPH_MASKBIT',['../prcm_8c.html#a7daf8f126ab7597c57c7a3fb909b6756',1,'prcm.c']]]
];
