var group__setup__api =
[
    [ "trimDevice", "group__setup__api.html#ga44b5aa29442508f95d7eba504885f019", null ]
];