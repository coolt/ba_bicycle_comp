var searchData=
[
  ['hwrevision_5ft',['HwRevision_t',['../group___chip_info.html#gaf8564d05659c381283c892f605667362',1,'chipinfo.h']]]
];
