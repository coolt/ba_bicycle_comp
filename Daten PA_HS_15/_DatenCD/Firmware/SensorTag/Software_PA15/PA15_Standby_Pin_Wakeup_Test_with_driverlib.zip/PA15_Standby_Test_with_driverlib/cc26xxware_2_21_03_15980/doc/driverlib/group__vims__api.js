var group__vims__api =
[
    [ "VIMSConfigure", "group__vims__api.html#ga33025ed4f7c5b3694f1bbc198e36e3e8", null ],
    [ "VIMSLineBufDisable", "group__vims__api.html#gab4b55e753335553abd2d3aa13f2f10bb", null ],
    [ "VIMSLineBufEnable", "group__vims__api.html#gaf1db2091144659ec5c1fd972a09f9275", null ],
    [ "VIMSModeGet", "group__vims__api.html#gaf2a0eaa5209f808c8e83f9dd3b0200f8", null ],
    [ "VIMSModeSet", "group__vims__api.html#ga1383305e90b9bd37527da503a9997c82", null ],
    [ "VIMSModeSetBlocking", "group__vims__api.html#ga34f71c41326148b0f576c257a812f081", null ],
    [ "VIMS_MODE_CHANGING", "group__vims__api.html#ga69dfbe2c403ab766b17e4ee9643017ee", null ],
    [ "VIMS_MODE_DISABLED", "group__vims__api.html#gab6d9ed00b7ea199bc7c6ecf27c33b08c", null ],
    [ "VIMS_MODE_ENABLED", "group__vims__api.html#gaa04ce8ff503d0950a37df11a84698638", null ],
    [ "VIMS_MODE_OFF", "group__vims__api.html#ga9310b66df313fb536e9556422be309f7", null ],
    [ "VIMS_MODE_SPLIT", "group__vims__api.html#ga5a8a046d0877009f4b7424c1a756dac5", null ]
];