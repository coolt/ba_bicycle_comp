var searchData=
[
  ['chipfamily_5ft',['ChipFamily_t',['../group___chip_info.html#ga4f490ca6779597fb7a7801f86cce0fa3',1,'chipinfo.h']]]
];
