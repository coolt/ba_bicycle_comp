var searchData=
[
  ['num_5fgpio_5fpins',['NUM_GPIO_PINS',['../group__gpio__api.html#gae1a70432cf02543f2f8e9432d6f0ef0c',1,'gpio.h']]],
  ['num_5fio_5fmax',['NUM_IO_MAX',['../group__ioc__api.html#ga893f96d3d27499bdf2b59aa5b45c8238',1,'ioc.h']]],
  ['num_5fio_5fports',['NUM_IO_PORTS',['../group__ioc__api.html#ga6db8eeed00dc9c2cb0f67df746dc6142',1,'ioc.h']]]
];
