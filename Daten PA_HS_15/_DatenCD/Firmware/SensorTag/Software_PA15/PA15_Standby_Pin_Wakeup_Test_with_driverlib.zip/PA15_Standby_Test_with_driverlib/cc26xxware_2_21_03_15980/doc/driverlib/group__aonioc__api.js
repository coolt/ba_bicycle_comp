var group__aonioc__api =
[
    [ "AONIOC32kHzOutputDisable", "group__aonioc__api.html#ga2fb70886230a3d24b834a26e175eba8b", null ],
    [ "AONIOC32kHzOutputEnable", "group__aonioc__api.html#ga3e2fc8bb075b470beb6969cbce5e073b", null ],
    [ "AONIOCDriveStrengthGet", "group__aonioc__api.html#ga6d364d76b9ee6025f8aaacb7bfb73700", null ],
    [ "AONIOCDriveStrengthSet", "group__aonioc__api.html#ga57b665392b0c5adcebb7f2d763582a1e", null ],
    [ "AONIOCFreezeDisable", "group__aonioc__api.html#ga6ea80201fd80c9df89bf44b239908ddc", null ],
    [ "AONIOCFreezeEnable", "group__aonioc__api.html#ga415be9a200650b0c093366100fb25277", null ],
    [ "AONIOC_DRV_STR10_20_40", "group__aonioc__api.html#ga79991f297d1f9609c1b92578fff666ec", null ],
    [ "AONIOC_DRV_STR14_28_56", "group__aonioc__api.html#ga8a7152e45d97fa259cd456079ca69419", null ],
    [ "AONIOC_DRV_STR20_40_80", "group__aonioc__api.html#ga60f6af0061b102b51e1f3e33fa5e292c", null ],
    [ "AONIOC_DRV_STR28_56_112", "group__aonioc__api.html#ga59735366079010208374fc6107a01f97", null ],
    [ "AONIOC_DRV_STR40_80_112", "group__aonioc__api.html#ga177b6d1f643d048edcf32e7128e5ec6b", null ],
    [ "AONIOC_DRV_STR5_10_20", "group__aonioc__api.html#ga691018a823bf639943c71a31116c93e9", null ],
    [ "AONIOC_DRV_STR5_7_14", "group__aonioc__api.html#ga80dd6aed5cc6627b4965ab47768e0ad0", null ],
    [ "AONIOC_DRV_STR7_14_28", "group__aonioc__api.html#gaeb797e22a2586d992af3320d0d1bc762", null ],
    [ "AONIOC_MAX_DRIVE", "group__aonioc__api.html#ga1a6b62c7202f3a82a46c4f09b0d18ae0", null ],
    [ "AONIOC_MED_DRIVE", "group__aonioc__api.html#ga66f6b094aac3bc800d60874b60004e23", null ],
    [ "AONIOC_MIN_DRIVE", "group__aonioc__api.html#ga89caa517a8363395e743478d87c8a3c7", null ]
];