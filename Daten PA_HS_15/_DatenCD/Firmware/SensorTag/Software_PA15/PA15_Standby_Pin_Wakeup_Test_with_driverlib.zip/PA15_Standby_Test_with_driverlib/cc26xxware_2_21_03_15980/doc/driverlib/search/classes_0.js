var searchData=
[
  ['hard_5fapi_5ft',['HARD_API_T',['../struct_h_a_r_d___a_p_i___t.html',1,'']]]
];
