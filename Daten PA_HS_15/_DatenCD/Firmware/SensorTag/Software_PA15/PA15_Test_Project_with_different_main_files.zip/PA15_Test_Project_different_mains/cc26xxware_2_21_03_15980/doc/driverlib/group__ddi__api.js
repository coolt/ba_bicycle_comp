var group__ddi__api =
[
    [ "AuxAdiDdiSafeRead", "group__ddi__api.html#ga8175a094afd96e5f440a276c4cc7fe44", null ],
    [ "AuxAdiDdiSafeWrite", "group__ddi__api.html#ga06d6b1eee2c8757b8431eb6e1ab98f68", null ],
    [ "DDI16BitfieldRead", "group__ddi__api.html#gac86ccf0590b9dbdc88eb1a6c856c78a4", null ],
    [ "DDI16BitfieldWrite", "group__ddi__api.html#ga492326c095c70621a247fe02a2cb09e4", null ],
    [ "DDI16BitRead", "group__ddi__api.html#ga84659279c1c1167d77484ac1aeaa8b11", null ],
    [ "DDI16BitWrite", "group__ddi__api.html#gabdbaae7ecb063e23cb2f12198f419a5e", null ],
    [ "DDI16SetValBit", "group__ddi__api.html#gaa20eda893cdfa6c71edcca12a28f97d6", null ],
    [ "DDI32BitsClear", "group__ddi__api.html#gad807ccc921f1e73a9fd1a027ad006731", null ],
    [ "DDI32BitsSet", "group__ddi__api.html#gaaf698b2544673b8268982a4b949a702e", null ],
    [ "DDI32RegRead", "group__ddi__api.html#ga5281eb67759a17191879a9971495404c", null ],
    [ "DDI32RegWrite", "group__ddi__api.html#ga184dde81e5106887c63cf6a580b95308", null ],
    [ "DDI8SetValBit", "group__ddi__api.html#gab273ce11e9b782e2a387c136547863e0", null ],
    [ "DDI_ACK", "group__ddi__api.html#ga2c5761ff57302c315ff49b99eded5ab0", null ],
    [ "DDI_PROTECT", "group__ddi__api.html#ga211ff045ab46c09200c98875585fde32", null ],
    [ "DDI_SLAVE_REGS", "group__ddi__api.html#ga8df75da6d681ce056e4ac88ad0fb8f89", null ],
    [ "DDI_SYNC", "group__ddi__api.html#ga185cc10777334eb570ed6a6c779394ba", null ]
];