var searchData=
[
  ['_5f_5ferror_5f_5f',['__error__',['../group__debug__api.html#ga9cbff4035d547129f9c7c07129d2fa01',1,'__error__(char *pcFilename, uint32_t ui32Line):&#160;debug.c'],['../group__debug__api.html#ga9cbff4035d547129f9c7c07129d2fa01',1,'__error__(char *pcFilename, uint32_t ui32Line):&#160;debug.c']]],
  ['_5f_5fhapi_5fh_5f_5f',['__HAPI_H__',['../rom_8h.html#af1e640afedecf14758ace5fef1a8ba0b',1,'rom.h']]]
];
