var searchData=
[
  ['xosc_5fin_5fhigh_5fpower_5fmode',['XOSC_IN_HIGH_POWER_MODE',['../group__sysctrl__api.html#ga6e16fb028b341da513a358276d7cf58a',1,'sys_ctrl.h']]],
  ['xosc_5fin_5flow_5fpower_5fmode',['XOSC_IN_LOW_POWER_MODE',['../group__sysctrl__api.html#ga3ae68574a85e91bad0f8e262bdc014d9',1,'sys_ctrl.h']]],
  ['xoscinhighpowermode',['XoscInHighPowerMode',['../group__sysctrl__api.html#gaa7e73e19f382b70fb163c35694334cd9',1,'sys_ctrl.h']]],
  ['xoscinlowpowermode',['XoscInLowPowerMode',['../group__sysctrl__api.html#gae231dc061ce894fe0bca7ed5448f3654',1,'sys_ctrl.h']]]
];
