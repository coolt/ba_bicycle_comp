var group__aonbatmon__api =
[
    [ "AONBatMonBatteryVoltageGet", "group__aonbatmon__api.html#ga9fa932b57660b7ff1062ca41ff31226a", null ],
    [ "AONBatMonDisable", "group__aonbatmon__api.html#ga386612bb4fe84ba553f4308bb44868a4", null ],
    [ "AONBatMonEnable", "group__aonbatmon__api.html#ga2fc2477dc3786fb2f6652750c6132893", null ],
    [ "AONBatMonNewBatteryMeasureReady", "group__aonbatmon__api.html#ga7548d83fcaae3ac439cb5e1bb347d586", null ],
    [ "AONBatMonNewTempMeasureReady", "group__aonbatmon__api.html#gaf7f6e520d01acdee17bd9f8d0f0e2916", null ],
    [ "AONBatMonTemperatureGetDegC", "group__aonbatmon__api.html#gadc33e3e057f96ec6fc9fff57bd64de57", null ]
];