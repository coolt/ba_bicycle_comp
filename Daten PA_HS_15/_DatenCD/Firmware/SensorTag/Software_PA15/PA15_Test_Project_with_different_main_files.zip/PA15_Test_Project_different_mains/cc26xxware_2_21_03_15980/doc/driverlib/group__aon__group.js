var group__aon__group =
[
    [ "[aon_batmon] AON Battery Monitor", "group__aonbatmon__api.html", "group__aonbatmon__api" ],
    [ "[aon_event] AON Event", "group__aonevent__api.html", "group__aonevent__api" ],
    [ "[aon_ioc] AON I/O Controller", "group__aonioc__api.html", "group__aonioc__api" ],
    [ "[aon_rtc] AON Real Time Clock", "group__aonrtc__api.html", "group__aonrtc__api" ],
    [ "[aon_wuc] AON Wake Up Controller", "group__aonwuc__api.html", "group__aonwuc__api" ]
];