var group__rfc__api =
[
    [ "RFCAckIntClear", "group__rfc__api.html#gacb5c7586157fe392827ef85c4ad86159", null ],
    [ "RFCClockDisable", "group__rfc__api.html#gab15583611cfe91480102dd4b6299f2ba", null ],
    [ "RFCClockEnable", "group__rfc__api.html#gaf68f6a38c012dda29e0bfa4713d86c02", null ],
    [ "RFCCpe0IntEnable", "group__rfc__api.html#ga21f6a829d69bd5ed9d4797a7728ec7d1", null ],
    [ "RFCCpe1IntEnable", "group__rfc__api.html#gae36a45666f6bdde91100249e0e2aa39b", null ],
    [ "RFCCpeIntClear", "group__rfc__api.html#ga93310824c500ce3b6d9ce7a456e0182a", null ],
    [ "RFCCpeIntDisable", "group__rfc__api.html#gaffdbf018570ce2dc8a194ccf495a7260", null ],
    [ "RFCCpeIntGetAndClear", "group__rfc__api.html#ga7f336c6cf90711f668ce68eb9d066f8c", null ],
    [ "RFCHwIntClear", "group__rfc__api.html#ga275ada94a9c942227c5ca33be6a3de1c", null ],
    [ "RFCHwIntDisable", "group__rfc__api.html#gade44c847689af61b7336736a2fca8db2", null ],
    [ "RFCHwIntEnable", "group__rfc__api.html#ga98f19ea55cb062e5e79538ee2b8c8ecb", null ]
];