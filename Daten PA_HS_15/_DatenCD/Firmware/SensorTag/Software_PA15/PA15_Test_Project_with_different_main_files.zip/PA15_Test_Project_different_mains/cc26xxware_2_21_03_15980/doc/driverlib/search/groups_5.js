var searchData=
[
  ['system_20control',['System Control',['../group__system__control__group.html',1,'']]],
  ['system_20cpu',['System CPU',['../group__system__cpu__group.html',1,'']]]
];
