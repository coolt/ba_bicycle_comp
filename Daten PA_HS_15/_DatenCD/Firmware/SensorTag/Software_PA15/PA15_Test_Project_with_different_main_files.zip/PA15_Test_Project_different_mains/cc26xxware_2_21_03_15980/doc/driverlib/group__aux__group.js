var group__aux__group =
[
    [ "[aux_adc] AUX Analog to Digital Converter", "group__auxadc__api.html", "group__auxadc__api" ],
    [ "[aux_smph] AUX Semaphore", "group__auxsmph__api.html", "group__auxsmph__api" ],
    [ "[aux_tdc] AUX Time to Digital Converter", "group__auxtdc__api.html", "group__auxtdc__api" ],
    [ "[aux_timer] AUX Timer", "group__auxtimer__api.html", "group__auxtimer__api" ],
    [ "[aux_wuc] AUX Wake Up Controller", "group__auxwuc__api.html", "group__auxwuc__api" ]
];