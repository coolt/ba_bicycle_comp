var group__cpu__api =
[
    [ "CPUbasepriGet", "group__cpu__api.html#ga31fd39ee16277d1a44ab2b0e57afa958", null ],
    [ "CPUbasepriSet", "group__cpu__api.html#ga99e0a54b481e2115f44f2c448701cf73", null ],
    [ "CPUcpsid", "group__cpu__api.html#ga491d851c4f7fff1f9f66aa778b0671b0", null ],
    [ "CPUcpsie", "group__cpu__api.html#ga6922d401cbc951632f495ffcf2e71dfc", null ],
    [ "CPUdelay", "group__cpu__api.html#ga6a8880327e662906b655bf709bf179e7", null ],
    [ "CPUprimask", "group__cpu__api.html#ga30b582aa911c86da4d45c11462c2938a", null ],
    [ "CPUsev", "group__cpu__api.html#ga0ea3757620997b9a6f896ae8b01a16e2", null ],
    [ "CPUwfe", "group__cpu__api.html#gaabb5ecab4c0b83eff7be9c87972b791f", null ],
    [ "CPUwfi", "group__cpu__api.html#ga28849d778ab8d1eb9dd29ad07fc7c845", null ]
];