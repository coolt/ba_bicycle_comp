var searchData=
[
  ['oscclocksourceget',['OSCClockSourceGet',['../group__osc__api.html#ga279bd3a34548bd4c5e2fc6939f7be228',1,'OSCClockSourceGet(uint32_t ui32SrcClk):&#160;osc.c'],['../group__osc__api.html#ga279bd3a34548bd4c5e2fc6939f7be228',1,'OSCClockSourceGet(uint32_t ui32SrcClk):&#160;osc.c']]],
  ['oscclocksourceset',['OSCClockSourceSet',['../group__osc__api.html#ga37a02687fbd8680396550f682a7f046f',1,'OSCClockSourceSet(uint32_t ui32SrcClk, uint32_t ui32Osc):&#160;osc.c'],['../group__osc__api.html#ga37a02687fbd8680396550f682a7f046f',1,'OSCClockSourceSet(uint32_t ui32SrcClk, uint32_t ui32Osc):&#160;osc.c']]],
  ['oschf_5fattempttoswitchtoxosc',['OSCHF_AttemptToSwitchToXosc',['../group__osc__api.html#ga47914d2750ee826560f2107a567bb1a4',1,'OSCHF_AttemptToSwitchToXosc(void):&#160;osc.c'],['../group__osc__api.html#ga47914d2750ee826560f2107a567bb1a4',1,'OSCHF_AttemptToSwitchToXosc(void):&#160;osc.c']]],
  ['oschf_5fgetstartuptime',['OSCHF_GetStartupTime',['../group__osc__api.html#ga8f7fce82e80c984531622af61963db51',1,'OSCHF_GetStartupTime(uint32_t timeUntilWakeupInMs):&#160;osc.c'],['../group__osc__api.html#ga8f7fce82e80c984531622af61963db51',1,'OSCHF_GetStartupTime(uint32_t timeUntilWakeupInMs):&#160;osc.c']]],
  ['oschf_5fswitchtorcoscturnoffxosc',['OSCHF_SwitchToRcOscTurnOffXosc',['../group__osc__api.html#ga9eeb99e769d9c911305ff4c3c33c736c',1,'OSCHF_SwitchToRcOscTurnOffXosc(void):&#160;osc.c'],['../group__osc__api.html#ga9eeb99e769d9c911305ff4c3c33c736c',1,'OSCHF_SwitchToRcOscTurnOffXosc(void):&#160;osc.c']]],
  ['oschf_5fturnonxosc',['OSCHF_TurnOnXosc',['../group__osc__api.html#gaee5a511c4ca70e8eb66f4a6252488506',1,'OSCHF_TurnOnXosc(void):&#160;osc.c'],['../group__osc__api.html#gaee5a511c4ca70e8eb66f4a6252488506',1,'OSCHF_TurnOnXosc(void):&#160;osc.c']]],
  ['oschfsourceready',['OSCHfSourceReady',['../group__osc__api.html#gae135dfece97e821338b93c4b32bc6980',1,'osc.h']]],
  ['oschfsourceswitch',['OSCHfSourceSwitch',['../group__osc__api.html#gac21e7c4532672c8fa7b90e493359ddc2',1,'osc.h']]],
  ['oscinterfacedisable',['OSCInterfaceDisable',['../group__osc__api.html#ga16a6436817d18fdeef1fa514bb805047',1,'osc.h']]],
  ['oscinterfaceenable',['OSCInterfaceEnable',['../group__osc__api.html#ga6fb2cee20c657b549d534219a41c1428',1,'OSCInterfaceEnable(void):&#160;osc.c'],['../group__osc__api.html#ga6fb2cee20c657b549d534219a41c1428',1,'OSCInterfaceEnable(void):&#160;osc.c']]],
  ['oscxhfpowermodeset',['OSCXHfPowerModeSet',['../group__osc__api.html#ga5f00114c27141d4a48934cad95b0daa0',1,'osc.h']]]
];
