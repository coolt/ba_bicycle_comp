var searchData=
[
  ['delay_5f20_5fusec',['DELAY_20_USEC',['../setup_8c.html#a37436afb85c00b992e60e4430e7ccc63',1,'setup.c']]]
];
