var group__debug__api =
[
    [ "__error__", "group__debug__api.html#ga9cbff4035d547129f9c7c07129d2fa01", null ],
    [ "ASSERT", "group__debug__api.html#ga28301f76c53b643912da7c538f74e2c6", null ]
];